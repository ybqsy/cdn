<?php

$config = [
	'spaceId' => 'cc8cf08f-49f5-4fc5-83c3-ed2a683704d4',
	'clientSecret' => '+KeAC1QXyDC+46Wm/yxJNQ==',
];